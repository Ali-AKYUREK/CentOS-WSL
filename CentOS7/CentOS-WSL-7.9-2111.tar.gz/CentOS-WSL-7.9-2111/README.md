# CentOS WSL

[CentOS](https://www.centos.org/) QCOW2 cloud images converted to RootFS for [WSL](https://docs.microsoft.com/en-us/windows/wsl/).

## Main branch:
- [CentOS WSL](https://github.com/mishamosher/CentOS-WSL)